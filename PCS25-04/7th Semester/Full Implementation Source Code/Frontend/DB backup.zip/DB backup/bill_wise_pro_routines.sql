CREATE DATABASE  IF NOT EXISTS `bill_wise_pro` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bill_wise_pro`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bill_wise_pro
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'bill_wise_pro'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddUserAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddUserAccount`(
    IN p_name VARCHAR(45),
    IN p_gstin VARCHAR(20),
    IN p_phone_number VARCHAR(15),
    IN p_email VARCHAR(45),
    IN p_company_name VARCHAR(45),
    IN p_address VARCHAR(450)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Rollback the transaction in case of error
        ROLLBACK;

        -- Log the error into the ErrorLog table
        INSERT INTO ErrorLog (error_message) VALUES (CONCAT('Error occurred while adding user: ', LAST_INSERT_ID()));
    END;

    -- Start a transaction
    START TRANSACTION;

    -- Insert the user account
    INSERT INTO UserAccount (name, gstin, phone_number, email, company_name, address)
    VALUES (p_name, p_gstin, p_phone_number, p_email, p_company_name, p_address);

    -- Commit the transaction
    COMMIT;

    -- Return the ID of the inserted user
    SELECT LAST_INSERT_ID() AS user_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreateClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateClient`(
    IN p_name VARCHAR(45),
    IN p_gstin VARCHAR(20),
    IN p_phone_number VARCHAR(15),
    IN p_email VARCHAR(45),
    IN p_address VARCHAR(450),
    IN p_to_get DOUBLE,
    IN p_to_pay DOUBLE,
    IN p_notice_period INT,
    IN p_user_id INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        DECLARE error_message TEXT;
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error creating client: ', error_message));
        ROLLBACK;
    END;

    START TRANSACTION;

    INSERT INTO client (name, gstin, phone_number, email, address, user_id, to_get, to_pay, notice_period, deleted)
    VALUES (p_name, p_gstin, p_phone_number, p_email, p_address, p_user_id, p_to_get, p_to_pay, p_notice_period, 0);

    COMMIT;
    SELECT LAST_INSERT_ID() AS client_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreateProduct` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateProduct`(
    IN p_hsn VARCHAR(15),
    IN p_name VARCHAR(45),
    IN p_sale_price DOUBLE,
    IN p_cost_price DOUBLE,
    IN p_tax FLOAT,
    IN p_quantity BIGINT,
    IN p_user_id INT
)
BEGIN
    -- Declare variables and error handler at the beginning of the block
    DECLARE error_message TEXT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Rollback the transaction on error
        ROLLBACK;

        -- Get the error message
        GET DIAGNOSTICS CONDITION 1
            error_message = MESSAGE_TEXT;

        -- Insert the real error message into the error log
        INSERT INTO error_log (error_message) VALUES (error_message);
    END;

    -- Start a transaction
    START TRANSACTION;

    -- Attempt to insert the product
    INSERT INTO product (hsn, name, sale_price, cost_price, tax, quantity, user_id)
    VALUES (p_hsn, p_name, p_sale_price, p_cost_price, p_tax, p_quantity, p_user_id);
    
    -- If insert is successful, commit the transaction
    COMMIT;

    -- Return the last inserted ID
    SELECT LAST_INSERT_ID() AS product_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteClient`(
    IN p_id INT
)
BEGIN
    DECLARE error_message TEXT;
	DECLARE row_count INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error deleting client ID ', p_id, ': ', error_message));
        ROLLBACK;
    END;

    START TRANSACTION;

    UPDATE client
    SET deleted = 1
    WHERE id = p_id AND deleted = 0;
	GET DIAGNOSTICS row_count = ROW_COUNT;
    COMMIT;
    -- Return the number of rows affected
    SELECT row_count AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteClientById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteClientById`(
    IN p_id INT
)
BEGIN
    DECLARE error_message TEXT;
	DECLARE row_count INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error deleting client ID ', p_id, ': ', error_message));
        ROLLBACK;
    END;

    START TRANSACTION;

    UPDATE client
    SET deleted = 1
    WHERE id = p_id AND deleted = 0;
	GET DIAGNOSTICS row_count = ROW_COUNT;
    COMMIT;
    -- Return the number of rows affected
    SELECT row_count AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteInvoiceById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteInvoiceById`(
    IN p_sale_purchase_id INT
)
BEGIN
    DECLARE v_type ENUM('SALE', 'PURCHASE');
    DECLARE v_client_id INT;
    DECLARE v_total_amount DOUBLE;
    DECLARE v_discount_amount DOUBLE;
    DECLARE v_amount_received DOUBLE;
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_product_id BIGINT;
    DECLARE v_quantity BIGINT;
    
    DECLARE cur CURSOR FOR
        SELECT product_id, quantity
        FROM transactionitem
        WHERE sale_and_purchase_id = p_sale_purchase_id;
        
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log the error
        INSERT INTO errorlog (error_message, error_time)
        VALUES (CONCAT('Error deleting sale and purchase record ID: ', p_sale_purchase_id), NOW());
        -- Rollback the transaction
        ROLLBACK;
        -- Return failure status
        SELECT 0 AS status;
    END;

    -- Start transaction to ensure atomicity
    START TRANSACTION;

    -- Check if there is a sale and purchase record with the given ID
    IF EXISTS (SELECT 1 FROM saleandpurchaserecord WHERE id = p_sale_purchase_id And deleted = 0) THEN
        -- Fetch type and client_id from saleandpurchaserecord
        SELECT type, client_id INTO v_type, v_client_id
        FROM saleandpurchaserecord
        WHERE id = p_sale_purchase_id;

        -- Fetch total amount, discount amount, and amount received from transaction
        SELECT total_amount, discount_amount, amount_received INTO v_total_amount, v_discount_amount, v_amount_received
        FROM transaction
        WHERE sale_and_purchase_id = p_sale_purchase_id;

        -- Mark the sale and purchase record as deleted
        UPDATE saleandpurchaserecord
        SET deleted = 1
        WHERE id = p_sale_purchase_id;

        -- Revert client balances based on sale or purchase type
        IF v_type = 'SALE' THEN
            -- Revert client's to_get and to_pay balances
            UPDATE client
            SET 
                to_get = GREATEST(0, COALESCE(to_get, 0) - (v_total_amount - v_amount_received)), 
                to_pay = GREATEST(0, COALESCE(to_pay, 0) + v_amount_received)
            WHERE id = v_client_id;
        ELSE -- PURCHASE
            -- Revert client's to_pay and to_get balances
            UPDATE client
            SET 
                to_pay = GREATEST(0, COALESCE(to_pay, 0) - (v_total_amount - v_amount_received)), 
                to_get = GREATEST(0, COALESCE(to_get, 0) + v_amount_received)
            WHERE id = v_client_id;
        END IF;

        -- Revert product quantities based on sale or purchase
        OPEN cur;
        read_loop: LOOP
            FETCH cur INTO v_product_id, v_quantity;

            IF done THEN
                LEAVE read_loop;
            END IF;

            IF v_type = 'SALE' THEN
                -- For sale, revert by increasing product quantity
                UPDATE product
                SET quantity = quantity + v_quantity
                WHERE id = v_product_id;
            ELSE
                -- For purchase, revert by decreasing product quantity
                UPDATE product
                SET quantity = quantity - v_quantity
                WHERE id = v_product_id;
            END IF;
        END LOOP;
        CLOSE cur;

        -- Commit the transaction
        COMMIT;
        SELECT 1 AS status;

    ELSE
        ROLLBACK;
        SELECT 0 AS status;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteProductById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteProductById`(
    IN p_id BIGINT
)
BEGIN
    DECLARE error_message TEXT;
    DECLARE row_count INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Rollback the transaction on error (if needed)
        ROLLBACK;

        -- Log the error message to the error_log table
        GET DIAGNOSTICS CONDITION 1
            error_message = MESSAGE_TEXT;

        INSERT INTO error_log (error_message) VALUES (error_message);
    END;

    START TRANSACTION;

    -- Updating the product to mark it as deleted
    UPDATE product 
    SET deleted = 1 
    WHERE id = p_id AND deleted = 0;

    -- Get the number of affected rows
    GET DIAGNOSTICS row_count = ROW_COUNT;

    COMMIT;

    -- Return the number of affected rows
    SELECT row_count AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GenerateInvoice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerateInvoice`(
    IN p_user_id INT,
    IN p_client_id INT,
    IN p_type ENUM('SALE', 'PURCHASE'),
    IN p_payment_method ENUM('CASH', 'ONLINE'),
    IN p_total_amount DOUBLE,
    IN p_discount_amount DOUBLE,
    IN p_amount_received DOUBLE,
    IN p_shipping_address VARCHAR(255)  -- Added parameter for shipping address
)
BEGIN
    DECLARE v_due_date DATE;
    DECLARE v_to_get DOUBLE;
    DECLARE v_to_pay DOUBLE;
    DECLARE v_status ENUM('PAID', 'UNPAID', 'OVERDUE');
    DECLARE v_notice_period INT DEFAULT 0;
    DECLARE v_payment_method_id INT;
    DECLARE v_date_issued DATE;
    DECLARE v_sale_purchase_id INT;
    DECLARE v_current_to_get DOUBLE DEFAULT 0;
    DECLARE v_current_to_pay DOUBLE DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        -- Log error
        INSERT INTO errorlog (error_message, error_time) 
        VALUES (CONCAT('Error generating invoice for client ID: ', p_client_id, ', User ID: ', p_user_id), NOW());
    END;

    -- Get the current date as date_issued
    SET v_date_issued = CURRENT_DATE();

    -- Retrieve notice period from the client table along with the current balances
    SELECT notice_period, to_get, to_pay INTO v_notice_period, v_current_to_get, v_current_to_pay
    FROM client
    WHERE id = p_client_id;

    -- Calculate due date based on notice period
    IF v_notice_period IS NOT NULL THEN
        SET v_due_date = DATE_ADD(v_date_issued, INTERVAL v_notice_period DAY);
    ELSE
        SET v_due_date = v_date_issued;  -- Default due date if notice_period is NULL
    END IF;

    -- Calculate to_get and to_pay based on the type and existing client balances
    IF p_type = 'SALE' THEN
        -- Sale case: Deduct from to_pay if there's an outstanding to_pay amount
        IF (p_total_amount - p_amount_received) > 0 THEN
            IF v_current_to_pay > 0 THEN
                SET v_to_pay = LEAST(v_current_to_pay, p_total_amount - p_amount_received);
                SET v_to_get = (p_total_amount - p_amount_received) - v_to_pay;
            ELSE
                SET v_to_get = p_total_amount - p_amount_received;
                SET v_to_pay = 0;
            END IF;
        ELSE
            SET v_to_get = 0;
            SET v_to_pay = ABS(p_total_amount - p_amount_received);
        END IF;
    ELSE -- PURCHASE
        -- Purchase case: Deduct from to_get if there's an outstanding to_get amount
        IF (p_total_amount - p_amount_received) > 0 THEN
            IF v_current_to_get > 0 THEN
                SET v_to_get = LEAST(v_current_to_get, p_total_amount - p_amount_received);
                SET v_to_pay = (p_total_amount - p_amount_received) - v_to_get;
            ELSE
                SET v_to_pay = p_total_amount - p_amount_received;
                SET v_to_get = 0;
            END IF;
        ELSE
            SET v_to_pay = 0;
            SET v_to_get = ABS(p_total_amount - p_amount_received);
        END IF;
    END IF;

    -- Ensure no negative values for to_get and to_pay
    IF v_to_get < 0 THEN
        SET v_to_get = 0;
    END IF;

    IF v_to_pay < 0 THEN
        SET v_to_pay = 0;
    END IF;

    -- Determine status
    IF (p_total_amount - p_amount_received) <= 0 THEN
        SET v_status = 'PAID';
    ELSE
        SET v_status = 'UNPAID';
    END IF;

    -- Insert into saleandpurchaserecord (with user_id and shipping_address)
    INSERT INTO saleandpurchaserecord (client_id, date, type, deleted, shipping_address, user_id)
    VALUES (p_client_id, v_date_issued, p_type, 0, p_shipping_address, p_user_id);
    
    -- Get last inserted id for sale and purchase record
    SET v_sale_purchase_id = LAST_INSERT_ID();

    -- Insert into invoice
    INSERT INTO invoice (sale_and_purchase_id, invoice_number, date_issued, due_date, total_amount, status)
    VALUES (v_sale_purchase_id, CONCAT('INV-', p_user_id, '-', v_sale_purchase_id), v_date_issued, v_due_date, p_total_amount, v_status);

    -- Retrieve payment method ID
    SELECT id INTO v_payment_method_id FROM paymentmethod WHERE name = p_payment_method;
    
    -- Insert into transaction table with discount
    INSERT INTO transaction (total_amount, discount_amount, amount_received, payment_method_id, sale_and_purchase_id)
    VALUES (p_total_amount, p_discount_amount, p_amount_received, v_payment_method_id, v_sale_purchase_id);

    -- Update client balances, ensuring values never go negative
    IF p_type = 'SALE' THEN
        UPDATE client
        SET 
            to_get = GREATEST(0, COALESCE(to_get, 0) + v_to_get), 
            to_pay = GREATEST(0, COALESCE(to_pay, 0) - v_to_pay)
        WHERE id = p_client_id;
    ELSE -- PURCHASE
        UPDATE client
        SET 
            to_pay = GREATEST(0, COALESCE(to_pay, 0) + v_to_pay), 
            to_get = GREATEST(0, COALESCE(to_get, 0) - v_to_get)
        WHERE id = p_client_id;
    END IF;

    -- Return the sale_purchase_id
    SELECT v_sale_purchase_id AS sale_purchase_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllClients` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllClients`(
    IN p_user_id INT,
    IN p_offset INT,
    IN p_page_size INT
)
BEGIN
    SELECT id, name, phone_number, to_get, to_pay
    FROM client
    WHERE deleted = 0 AND user_id = p_user_id
    LIMIT p_offset, p_page_size;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllProducts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllProducts`(
    IN p_user_id INT,
    IN p_offset INT,
    IN p_page_size INT
)
BEGIN
    SELECT id, name, sale_price, cost_price, quantity
    FROM product
    WHERE user_id = p_user_id
    AND deleted = 0
    LIMIT p_offset, p_page_size;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllTransactionsByClientId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllTransactionsByClientId`(
    IN p_client_id INT,
    IN p_offset INT,
    IN p_page_size INT
)
BEGIN
    SELECT t.*
    FROM transaction t 
    JOIN saleandpurchaserecord sp ON t.sale_and_purchase_id = sp.id 
    where sp.client_id =  p_client_id 
    ORDER BY sp.date DESC
    LIMIT p_offset, p_page_size;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetClientById`(
    IN p_id INT
)
BEGIN
    SELECT id,name,gstin,phone_number,email,address,to_get,to_pay FROM client WHERE id = p_id AND deleted = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetInvoiceById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetInvoiceById`(
    IN p_sale_purchase_id INT
)
BEGIN
    -- Fetch sale and purchase record information
    SELECT 
        spr.type AS invoiceType,
        spr.shipping_address AS shippingAddress,
        c.name AS clientName,
        c.address AS billingAddress
    FROM 
        saleandpurchaserecord spr
    LEFT JOIN 
        client c ON spr.client_id = c.id
    WHERE 
        spr.id = p_sale_purchase_id And spr.deleted = 0;

    -- Fetch invoice details related to the sale/purchase record
    SELECT 
        i.invoice_number AS invoiceNumber,
        i.date_issued AS issueDate,
        i.due_date AS dueDate,
        i.status AS status
    FROM 
        invoice i
    WHERE 
        i.sale_and_purchase_id = p_sale_purchase_id;

    -- Fetch transaction details related to the sale/purchase record
    SELECT 
        t.total_amount AS totalAmount,
        t.discount_amount AS discountAmount,
        t.amount_received AS amountReceived,
        pm.name AS paymentMethod
    FROM 
        transaction t
    LEFT JOIN 
        paymentmethod pm ON t.payment_method_id = pm.id
    WHERE 
        t.sale_and_purchase_id = p_sale_purchase_id;

    -- Fetch transaction items related to the sale/purchase record, including tax percentage from product table
    SELECT 
        p.name AS productName,
        ti.quantity,
        ti.sale_price AS salePrice,
        p.tax AS taxPercentage
    FROM 
        transactionitem ti
    LEFT JOIN 
        product p ON ti.product_id = p.id
    WHERE 
        ti.sale_and_purchase_id = p_sale_purchase_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLowStockProducts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLowStockProducts`(
   IN p_user_id INT,
   IN p_offset INT,
   IN p_page_size INT
)
BEGIN
    SELECT p.name, p.quantity
    FROM product p
    WHERE p.deleted = 0 
      AND p.quantity < p.min_qty 
      AND p.user_id = p_user_id
    LIMIT p_offset, p_page_size;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetMonthlyTransactionSummary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetMonthlyTransactionSummary`(
    IN p_user_id INT
)
BEGIN
    SELECT 
        SUM(CASE WHEN sp.type = 'SALE' THEN t.total_amount ELSE 0 END) AS total_sales,
        SUM(CASE WHEN sp.type = 'PURCHASE' THEN t.total_amount ELSE 0 END) AS total_purchases
    FROM saleandpurchaserecord sp
    LEFT JOIN transaction t ON sp.id = t.sale_and_purchase_id
    WHERE sp.user_id = p_user_id AND MONTH(sp.date) = MONTH(CURDATE()) AND YEAR(sp.date) = YEAR(CURDATE());
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetProductById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetProductById`(
    IN p_id BIGINT
)
BEGIN
    SELECT name, hsn, sale_price,cost_price,tax,quantity FROM product WHERE id = p_id AND deleted = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTransactionSummary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTransactionSummary`(
    IN p_user_id INT
)
BEGIN
    SELECT 
        SUM(CASE WHEN sp.type = 'SALE' THEN t.total_amount ELSE 0 END) AS total_sales,
        SUM(CASE WHEN sp.type = 'PURCHASE' THEN t.total_amount ELSE 0 END) AS total_purchases,
        SUM(c.to_get) AS total_to_get,
        SUM(c.to_pay) AS total_to_pay
    FROM saleandpurchaserecord sp
    LEFT JOIN transaction t ON sp.id = t.sale_and_purchase_id
    JOIN client c ON sp.client_id = c.id
    WHERE sp.user_id = p_user_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUnpaidDueTransactions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetUnpaidDueTransactions`(
    IN p_user_id INT,
    IN p_offset INT,
    IN p_page_size INT
)
BEGIN
    SELECT t.*, c.name AS client_name, c.phone_number, 
           CONVERT_TZ(i.due_date, '+00:00', '+05:30') AS due_date 
    FROM transaction t 
    JOIN saleandpurchaserecord sp ON t.sale_and_purchase_id = sp.id 
    JOIN client c ON sp.client_id = c.id 
    JOIN invoice i ON sp.id = i.sale_and_purchase_id
    WHERE sp.user_id = p_user_id 
      AND CONVERT_TZ(i.due_date, '+00:00', '+05:30') < NOW() 
      AND t.amount_received < t.total_amount
    LIMIT p_offset, p_page_size;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetUserById`(
    IN p_user_id INT
)
BEGIN
    -- Select all information for the user with the specified userId
    SELECT name,gstin,phone_number,email,company_name,address
    FROM UserAccount
    WHERE id = p_user_id AND deleted = 0;  -- Assuming you want to exclude deleted users
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LoginUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `LoginUser`(
    IN p_phone_number VARCHAR(15)
)
BEGIN
    -- Select user_id, name, and company_name based on the provided phone number
    SELECT id AS user_id, name, company_name
    FROM UserAccount
    WHERE phone_number = p_phone_number AND deleted = 0;  -- Assuming you want to exclude deleted users
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PayRemainingAmount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `PayRemainingAmount`(
    IN p_sale_purchase_id INT,
    IN p_amount_paid DOUBLE
)
BEGIN
    DECLARE v_type ENUM('SALE', 'PURCHASE');
    DECLARE v_client_id INT;
    DECLARE v_total_amount DOUBLE;
    DECLARE v_amount_received DOUBLE;
    DECLARE v_remaining_balance DOUBLE;
    DECLARE v_new_to_get DOUBLE;
    DECLARE v_new_to_pay DOUBLE;

    -- Declare an exit handler for SQL exceptions
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log the error
        INSERT INTO errorlog (error_message, error_time)
        VALUES (CONCAT('Error updating payment for sale_purchase_id: ', p_sale_purchase_id), NOW());
        -- Rollback transaction
        ROLLBACK;
        -- Return failure status
        SELECT 0 AS status;
    END;

    -- Start transaction to ensure atomicity
    START TRANSACTION;

    -- Check if a record exists in saleandpurchaserecord
    IF EXISTS (SELECT 1 FROM saleandpurchaserecord WHERE id = p_sale_purchase_id) THEN
        
        -- Fetch transaction details
        SELECT type, client_id INTO v_type, v_client_id
        FROM saleandpurchaserecord
        WHERE id = p_sale_purchase_id;

        SELECT total_amount, amount_received INTO v_total_amount, v_amount_received
        FROM transaction
        WHERE sale_and_purchase_id = p_sale_purchase_id;

        -- Calculate the remaining balance
        SET v_remaining_balance = v_total_amount - v_amount_received;

        -- Ensure that the amount paid does not exceed the remaining balance
        IF p_amount_paid <= v_remaining_balance THEN
            -- Update the amount received in the transaction
            UPDATE transaction
            SET amount_received = amount_received + p_amount_paid
            WHERE sale_and_purchase_id = p_sale_purchase_id;

            -- Check if the transaction is fully paid
            IF (v_amount_received + p_amount_paid) = v_total_amount THEN
                -- Update the invoice status to PAID
                UPDATE invoice
                SET status = 'PAID'
                WHERE sale_and_purchase_id = p_sale_purchase_id;
            END IF;

            -- Fetch current client balances
            SELECT to_get, to_pay INTO v_new_to_get, v_new_to_pay
            FROM client
            WHERE id = v_client_id;

            -- Adjust client balance based on sale or purchase
            IF v_type = 'SALE' THEN
                SET v_new_to_get = COALESCE(v_new_to_get, 0) - p_amount_paid;
                SET v_new_to_pay = COALESCE(v_new_to_pay, 0);
                IF v_new_to_get < 0 THEN
                    SET v_new_to_pay = v_new_to_pay + ABS(v_new_to_get);
                    SET v_new_to_get = 0;
                END IF;
            ELSE -- PURCHASE
                SET v_new_to_get = COALESCE(v_new_to_get, 0);
                SET v_new_to_pay = COALESCE(v_new_to_pay, 0) - p_amount_paid;
                IF v_new_to_pay < 0 THEN
                    SET v_new_to_get = v_new_to_get + ABS(v_new_to_pay);
                    SET v_new_to_pay = 0;
                END IF;
            END IF;
            
            UPDATE client
            SET 
                to_get = v_new_to_get,
                to_pay = v_new_to_pay
            WHERE id = v_client_id;

            COMMIT;

            -- Return success status
            SELECT 1 AS status;
        ELSE
            -- Rollback the transaction if overpayment
            ROLLBACK;
            SELECT 0 AS status;
        END IF;
    ELSE
        -- Rollback the transaction if no record exists
        ROLLBACK;
        SELECT 0 AS status;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateClient`(
    IN p_id INT,
    IN p_name VARCHAR(45),
    IN p_gstin VARCHAR(20),
    IN p_phone_number VARCHAR(15),
    IN p_email VARCHAR(45),
    IN p_address VARCHAR(450),
    IN p_to_get DOUBLE,
    IN p_to_pay DOUBLE,
    IN p_notice_period INT
)
BEGIN
    DECLARE error_message TEXT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error updating client ID ', p_id, ': ', error_message));
        ROLLBACK;
    END;

    START TRANSACTION;

    UPDATE client
    SET name = p_name,
        gstin = p_gstin,
        phone_number = p_phone_number,
        email = p_email,
        address = p_address,
        to_get = p_to_get,
        to_pay = p_to_pay,
        notice_period = p_notice_period
    WHERE id = p_id AND deleted = 0;

    COMMIT;
    SELECT ROW_COUNT() AS rows_affected;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateClientById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateClientById`(
    IN p_id INT,
    IN p_name VARCHAR(45),
    IN p_gstin VARCHAR(20),
    IN p_phone_number VARCHAR(15),
    IN p_email VARCHAR(45),
    IN p_address VARCHAR(450),
    IN p_to_get DOUBLE,
    IN p_to_pay DOUBLE,
    IN p_notice_period INT
)
BEGIN
    DECLARE error_message TEXT;
	DECLARE row_count INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error updating client ID ', p_id, ': ', error_message));
        ROLLBACK;
    END;

    START TRANSACTION;

    UPDATE client
    SET name = p_name,
        gstin = p_gstin,
        phone_number = p_phone_number,
        email = p_email,
        address = p_address,
        to_get = p_to_get,
        to_pay = p_to_pay,
        notice_period = p_notice_period
    WHERE id = p_id AND deleted = 0;
	GET DIAGNOSTICS row_count = ROW_COUNT;
    COMMIT;
    SELECT row_count AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateProductById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateProductById`(
    IN p_id BIGINT,
    IN p_hsn VARCHAR(15),
    IN p_name VARCHAR(45),
    IN p_sale_price DOUBLE,
    IN p_cost_price DOUBLE,
    IN p_tax FLOAT,
    IN p_quantity BIGINT
)
BEGIN
    DECLARE error_message TEXT;
    DECLARE row_count INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Rollback the transaction on error
        ROLLBACK;

        -- Log the error message to the error_log table
        GET DIAGNOSTICS CONDITION 1
            error_message = MESSAGE_TEXT;

        INSERT INTO error_log (error_message) VALUES (error_message);
    END;

    START TRANSACTION;

    -- Updating the product
    UPDATE product
    SET
        hsn = p_hsn,
        name = p_name,
        sale_price = p_sale_price,
        cost_price = p_cost_price,
        tax = p_tax,
        quantity = p_quantity
    WHERE id = p_id AND deleted = 0;

    -- Get the number of affected rows
    GET DIAGNOSTICS row_count = ROW_COUNT;

    COMMIT;

    -- Return the number of affected rows
    SELECT row_count AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateProductQuantities` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateProductQuantities`(
    IN p_sale_purchase_id INT,  
    IN p_type ENUM('SALE', 'PURCHASE')
)
BEGIN
    DECLARE v_product_id BIGINT;
    DECLARE v_quantity BIGINT;
    DECLARE done INT DEFAULT FALSE;

    -- Declare a cursor to fetch transaction items
    DECLARE cur CURSOR FOR
        SELECT product_id, quantity
        FROM transactionitem
        WHERE sale_and_purchase_id = p_sale_purchase_id;

    -- Declare a handler for when the cursor is done
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Declare an exit handler for SQL exceptions
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log the error in the errorlog table
        INSERT INTO errorlog (error_message, error_time) 
        VALUES (CONCAT('Error updating product quantities for sale_and_purchase_id: ', p_sale_purchase_id), NOW());
    END;

    -- Open the cursor
    OPEN cur;

    -- Loop through the cursor
    read_loop: LOOP
        FETCH cur INTO v_product_id, v_quantity;

        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Update product quantities based on the transaction type (SALE or PURCHASE)
        IF p_type = 'SALE' THEN
            UPDATE product
            SET quantity = quantity - v_quantity
            WHERE id = v_product_id;
        ELSE -- PURCHASE
            UPDATE product
            SET quantity = quantity + v_quantity
            WHERE id = v_product_id;
        END IF;
    END LOOP;

    -- Close the cursor
    CLOSE cur;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateProductStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateProductStock`(
    IN p_product_id BIGINT,
    IN p_quantity_to_add BIGINT
)
BEGIN
    DECLARE error_message TEXT;
    DECLARE row_count INT;
    DECLARE product_quantity BIGINT;
    
    -- Error handler
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
        -- Log the error message
        INSERT INTO error_log (error_message) VALUES (CONCAT('Error updating stock for Product ID ', p_product_id, ': ', error_message));
        ROLLBACK;
    END;

    -- Start transaction
    START TRANSACTION;

    -- Check if the product exists
    SELECT quantity INTO product_quantity 
    FROM product 
    WHERE id = p_product_id;

    -- If no product found, raise an error
    IF product_quantity IS NULL THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Product not found';
    ELSE
        -- Update the product stock
        UPDATE product 
        SET quantity = quantity + p_quantity_to_add
        WHERE id = p_product_id AND deleted = 0;

        -- Get the number of rows affected
        GET DIAGNOSTICS row_count = ROW_COUNT;

        -- Commit the transaction
        COMMIT;

        -- Return the number of affected rows
        SELECT row_count AS affected_rows;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateUserInformation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateUserInformation`(
    IN p_user_id INT,
    IN p_name VARCHAR(45),
    IN p_gstin VARCHAR(20),
    IN p_phone_number VARCHAR(15),
    IN p_email VARCHAR(45),
    IN p_company_name VARCHAR(45),
    IN p_address VARCHAR(450)
)
BEGIN
    UPDATE UserAccount
    SET 
        name = p_name,
        gstin = p_gstin,
        phone_number = p_phone_number,
        email = p_email,
        company_name = p_company_name,
        address = p_address
    WHERE id = p_user_id AND deleted = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 12:44:44
