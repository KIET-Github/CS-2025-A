/** @type {import('tailwindcss').Config} */
// tailwind.config.js

module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primaryDark: '#191E29', // very dark background
        primaryBlue: '#132D46', // dark blue
        primaryGreen: '#01C38D', // aqua
        bgDark: '#0B1120', // even darker background
        textLight: '#E5E7EB', // light text
        textMuted: '#9CA3AF', // muted text
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'],
      },
    },
  },
  plugins: [],
}


