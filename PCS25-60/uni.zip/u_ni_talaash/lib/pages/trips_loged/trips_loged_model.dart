import '/components/modals/no_trip_booked_modal/no_trip_booked_modal_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'trips_loged_widget.dart' show TripsLogedWidget;
import 'package:flutter/material.dart';

class TripsLogedModel extends FlutterFlowModel<TripsLogedWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for RatingBar widget.
  double? ratingBarValue;
  // Model for NoTripBookedModal component.
  late NoTripBookedModalModel noTripBookedModalModel;

  @override
  void initState(BuildContext context) {
    noTripBookedModalModel =
        createModel(context, () => NoTripBookedModalModel());
  }

  @override
  void dispose() {
    noTripBookedModalModel.dispose();
  }
}
