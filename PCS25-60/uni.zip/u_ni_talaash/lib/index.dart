// Export pages
export '/pages/explore/explore_widget.dart' show ExploreWidget;
export '/pages/application_review/application_review_widget.dart'
    show ApplicationReviewWidget;
export '/pages/trips_loged/trips_loged_widget.dart' show TripsLogedWidget;
export '/pages/review_pages/review_five/review_five_widget.dart'
    show ReviewFiveWidget;
export '/create_account/login/login_widget.dart' show LoginWidget;
export '/create_account/create_profile/create_profile_widget.dart'
    show CreateProfileWidget;
export '/create_account/create_profile2/create_profile2_widget.dart'
    show CreateProfile2Widget;
export '/create_account/create_profile3/create_profile3_widget.dart'
    show CreateProfile3Widget;
export '/view_college/view_college_widget.dart' show ViewCollegeWidget;
export '/feed/feed_widget.dart' show FeedWidget;
export '/profile_page/profile_page_widget.dart' show ProfilePageWidget;
export '/profile_page_view/profile_page_view_widget.dart'
    show ProfilePageViewWidget;
export '/internship/internship_widget.dart' show InternshipWidget;
export '/applications/applications_widget.dart' show ApplicationsWidget;
export '/dash_board_login/dash_board_login_widget.dart'
    show DashBoardLoginWidget;
export '/dasboard_create_account/dasboard_create_account_widget.dart'
    show DasboardCreateAccountWidget;
export '/dash_board_home/dash_board_home_widget.dart' show DashBoardHomeWidget;
export '/dashboard_courses/dashboard_courses_widget.dart'
    show DashboardCoursesWidget;
export '/dashboard_profile/dashboard_profile_widget.dart'
    show DashboardProfileWidget;
export '/dash_board_add_college/dash_board_add_college_widget.dart'
    show DashBoardAddCollegeWidget;
export '/create_account_company/create_account_company_widget.dart'
    show CreateAccountCompanyWidget;
export '/complete_company/complete_company_widget.dart'
    show CompleteCompanyWidget;
export '/dashboard_company/dashboard_company_widget.dart'
    show DashboardCompanyWidget;
export '/company_offers/company_offers_widget.dart' show CompanyOffersWidget;
export '/company_login/company_login_widget.dart' show CompanyLoginWidget;
