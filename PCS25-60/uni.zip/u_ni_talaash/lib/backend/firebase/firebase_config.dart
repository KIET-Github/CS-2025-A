import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA-YobNE4mqpX0Gw4XHtPseOXKqUyqUHYM",
            authDomain: "projecttalaash01.firebaseapp.com",
            projectId: "projecttalaash01",
            storageBucket: "projecttalaash01.firebasestorage.app",
            messagingSenderId: "580321473691",
            appId: "1:580321473691:web:c62331deba73ccc580423e",
            measurementId: "G-5C1CMFD8Y5"));
  } else {
    await Firebase.initializeApp();
  }
}
