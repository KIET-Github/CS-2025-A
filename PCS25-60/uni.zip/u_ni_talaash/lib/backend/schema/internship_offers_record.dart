import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class InternshipOffersRecord extends FirestoreRecord {
  InternshipOffersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "companyId" field.
  DocumentReference? _companyId;
  DocumentReference? get companyId => _companyId;
  bool hasCompanyId() => _companyId != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "stipend" field.
  int? _stipend;
  int get stipend => _stipend ?? 0;
  bool hasStipend() => _stipend != null;

  // "duration" field.
  int? _duration;
  int get duration => _duration ?? 0;
  bool hasDuration() => _duration != null;

  // "skills" field.
  List<String>? _skills;
  List<String> get skills => _skills ?? const [];
  bool hasSkills() => _skills != null;

  // "openings" field.
  int? _openings;
  int get openings => _openings ?? 0;
  bool hasOpenings() => _openings != null;

  // "deadline" field.
  DateTime? _deadline;
  DateTime? get deadline => _deadline;
  bool hasDeadline() => _deadline != null;

  // "postedAt" field.
  DateTime? _postedAt;
  DateTime? get postedAt => _postedAt;
  bool hasPostedAt() => _postedAt != null;

  // "status" field.
  bool? _status;
  bool get status => _status ?? false;
  bool hasStatus() => _status != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "eligibility" field.
  List<String>? _eligibility;
  List<String> get eligibility => _eligibility ?? const [];
  bool hasEligibility() => _eligibility != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _companyId = snapshotData['companyId'] as DocumentReference?;
    _title = snapshotData['title'] as String?;
    _description = snapshotData['description'] as String?;
    _location = snapshotData['location'] as String?;
    _stipend = castToType<int>(snapshotData['stipend']);
    _duration = castToType<int>(snapshotData['duration']);
    _skills = getDataList(snapshotData['skills']);
    _openings = castToType<int>(snapshotData['openings']);
    _deadline = snapshotData['deadline'] as DateTime?;
    _postedAt = snapshotData['postedAt'] as DateTime?;
    _status = snapshotData['status'] as bool?;
    _type = snapshotData['type'] as String?;
    _eligibility = getDataList(snapshotData['eligibility']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('internshipOffers')
          : FirebaseFirestore.instance.collectionGroup('internshipOffers');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('internshipOffers').doc(id);

  static Stream<InternshipOffersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => InternshipOffersRecord.fromSnapshot(s));

  static Future<InternshipOffersRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => InternshipOffersRecord.fromSnapshot(s));

  static InternshipOffersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      InternshipOffersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static InternshipOffersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      InternshipOffersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'InternshipOffersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is InternshipOffersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createInternshipOffersRecordData({
  DocumentReference? companyId,
  String? title,
  String? description,
  String? location,
  int? stipend,
  int? duration,
  int? openings,
  DateTime? deadline,
  DateTime? postedAt,
  bool? status,
  String? type,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'companyId': companyId,
      'title': title,
      'description': description,
      'location': location,
      'stipend': stipend,
      'duration': duration,
      'openings': openings,
      'deadline': deadline,
      'postedAt': postedAt,
      'status': status,
      'type': type,
    }.withoutNulls,
  );

  return firestoreData;
}

class InternshipOffersRecordDocumentEquality
    implements Equality<InternshipOffersRecord> {
  const InternshipOffersRecordDocumentEquality();

  @override
  bool equals(InternshipOffersRecord? e1, InternshipOffersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.companyId == e2?.companyId &&
        e1?.title == e2?.title &&
        e1?.description == e2?.description &&
        e1?.location == e2?.location &&
        e1?.stipend == e2?.stipend &&
        e1?.duration == e2?.duration &&
        listEquality.equals(e1?.skills, e2?.skills) &&
        e1?.openings == e2?.openings &&
        e1?.deadline == e2?.deadline &&
        e1?.postedAt == e2?.postedAt &&
        e1?.status == e2?.status &&
        e1?.type == e2?.type &&
        listEquality.equals(e1?.eligibility, e2?.eligibility);
  }

  @override
  int hash(InternshipOffersRecord? e) => const ListEquality().hash([
        e?.companyId,
        e?.title,
        e?.description,
        e?.location,
        e?.stipend,
        e?.duration,
        e?.skills,
        e?.openings,
        e?.deadline,
        e?.postedAt,
        e?.status,
        e?.type,
        e?.eligibility
      ]);

  @override
  bool isValidKey(Object? o) => o is InternshipOffersRecord;
}
