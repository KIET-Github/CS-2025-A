import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class InternshipApplicationRecord extends FirestoreRecord {
  InternshipApplicationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "company" field.
  DocumentReference? _company;
  DocumentReference? get company => _company;
  bool hasCompany() => _company != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  void _initializeFields() {
    _user = snapshotData['user'] as DocumentReference?;
    _company = snapshotData['company'] as DocumentReference?;
    _createdTime = snapshotData['createdTime'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('InternshipApplication');

  static Stream<InternshipApplicationRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => InternshipApplicationRecord.fromSnapshot(s));

  static Future<InternshipApplicationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => InternshipApplicationRecord.fromSnapshot(s));

  static InternshipApplicationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      InternshipApplicationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static InternshipApplicationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      InternshipApplicationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'InternshipApplicationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is InternshipApplicationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createInternshipApplicationRecordData({
  DocumentReference? user,
  DocumentReference? company,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user': user,
      'company': company,
      'createdTime': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class InternshipApplicationRecordDocumentEquality
    implements Equality<InternshipApplicationRecord> {
  const InternshipApplicationRecordDocumentEquality();

  @override
  bool equals(
      InternshipApplicationRecord? e1, InternshipApplicationRecord? e2) {
    return e1?.user == e2?.user &&
        e1?.company == e2?.company &&
        e1?.createdTime == e2?.createdTime;
  }

  @override
  int hash(InternshipApplicationRecord? e) =>
      const ListEquality().hash([e?.user, e?.company, e?.createdTime]);

  @override
  bool isValidKey(Object? o) => o is InternshipApplicationRecord;
}
