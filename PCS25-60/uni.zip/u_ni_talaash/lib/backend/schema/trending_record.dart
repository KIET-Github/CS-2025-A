import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TrendingRecord extends FirestoreRecord {
  TrendingRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "institutions" field.
  List<DocumentReference>? _institutions;
  List<DocumentReference> get institutions => _institutions ?? const [];
  bool hasInstitutions() => _institutions != null;

  void _initializeFields() {
    _institutions = getDataList(snapshotData['institutions']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Trending');

  static Stream<TrendingRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TrendingRecord.fromSnapshot(s));

  static Future<TrendingRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TrendingRecord.fromSnapshot(s));

  static TrendingRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TrendingRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TrendingRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TrendingRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TrendingRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TrendingRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTrendingRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TrendingRecordDocumentEquality implements Equality<TrendingRecord> {
  const TrendingRecordDocumentEquality();

  @override
  bool equals(TrendingRecord? e1, TrendingRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.institutions, e2?.institutions);
  }

  @override
  int hash(TrendingRecord? e) => const ListEquality().hash([e?.institutions]);

  @override
  bool isValidKey(Object? o) => o is TrendingRecord;
}
