import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class InstitutionsRecord extends FirestoreRecord {
  InstitutionsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  // "nirf" field.
  String? _nirf;
  String get nirf => _nirf ?? '';
  bool hasNirf() => _nirf != null;

  // "campus_size_acres" field.
  double? _campusSizeAcres;
  double get campusSizeAcres => _campusSizeAcres ?? 0.0;
  bool hasCampusSizeAcres() => _campusSizeAcres != null;

  // "student_intake" field.
  int? _studentIntake;
  int get studentIntake => _studentIntake ?? 0;
  bool hasStudentIntake() => _studentIntake != null;

  // "average_placement_package_lpa" field.
  double? _averagePlacementPackageLpa;
  double get averagePlacementPackageLpa => _averagePlacementPackageLpa ?? 0.0;
  bool hasAveragePlacementPackageLpa() => _averagePlacementPackageLpa != null;

  // "institute_images" field.
  List<String>? _instituteImages;
  List<String> get instituteImages => _instituteImages ?? const [];
  bool hasInstituteImages() => _instituteImages != null;

  // "affiliatedTo" field.
  String? _affiliatedTo;
  String get affiliatedTo => _affiliatedTo ?? '';
  bool hasAffiliatedTo() => _affiliatedTo != null;

  // "highest_placement_package" field.
  String? _highestPlacementPackage;
  String get highestPlacementPackage => _highestPlacementPackage ?? '';
  bool hasHighestPlacementPackage() => _highestPlacementPackage != null;

  // "est_year" field.
  int? _estYear;
  int get estYear => _estYear ?? 0;
  bool hasEstYear() => _estYear != null;

  // "recruiters" field.
  List<String>? _recruiters;
  List<String> get recruiters => _recruiters ?? const [];
  bool hasRecruiters() => _recruiters != null;

  // "courses" field.
  List<String>? _courses;
  List<String> get courses => _courses ?? const [];
  bool hasCourses() => _courses != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  bool hasPhone() => _phone != null;

  // "logo" field.
  String? _logo;
  String get logo => _logo ?? '';
  bool hasLogo() => _logo != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "rank" field.
  int? _rank;
  int get rank => _rank ?? 0;
  bool hasRank() => _rank != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "rating" field.
  int? _rating;
  int get rating => _rating ?? 0;
  bool hasRating() => _rating != null;

  // "fees" field.
  double? _fees;
  double get fees => _fees ?? 0.0;
  bool hasFees() => _fees != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _city = snapshotData['city'] as String?;
    _state = snapshotData['state'] as String?;
    _nirf = snapshotData['nirf'] as String?;
    _campusSizeAcres = castToType<double>(snapshotData['campus_size_acres']);
    _studentIntake = castToType<int>(snapshotData['student_intake']);
    _averagePlacementPackageLpa =
        castToType<double>(snapshotData['average_placement_package_lpa']);
    _instituteImages = getDataList(snapshotData['institute_images']);
    _affiliatedTo = snapshotData['affiliatedTo'] as String?;
    _highestPlacementPackage =
        snapshotData['highest_placement_package'] as String?;
    _estYear = castToType<int>(snapshotData['est_year']);
    _recruiters = getDataList(snapshotData['recruiters']);
    _courses = getDataList(snapshotData['courses']);
    _description = snapshotData['description'] as String?;
    _website = snapshotData['website'] as String?;
    _email = snapshotData['email'] as String?;
    _phone = snapshotData['phone'] as String?;
    _logo = snapshotData['logo'] as String?;
    _category = snapshotData['category'] as String?;
    _rank = castToType<int>(snapshotData['rank']);
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _rating = castToType<int>(snapshotData['rating']);
    _fees = castToType<double>(snapshotData['fees']);
    _user = snapshotData['user'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('institutions');

  static Stream<InstitutionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => InstitutionsRecord.fromSnapshot(s));

  static Future<InstitutionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => InstitutionsRecord.fromSnapshot(s));

  static InstitutionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      InstitutionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static InstitutionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      InstitutionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'InstitutionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is InstitutionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createInstitutionsRecordData({
  String? name,
  String? city,
  String? state,
  String? nirf,
  double? campusSizeAcres,
  int? studentIntake,
  double? averagePlacementPackageLpa,
  String? affiliatedTo,
  String? highestPlacementPackage,
  int? estYear,
  String? description,
  String? website,
  String? email,
  String? phone,
  String? logo,
  String? category,
  int? rank,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  int? rating,
  double? fees,
  DocumentReference? user,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'city': city,
      'state': state,
      'nirf': nirf,
      'campus_size_acres': campusSizeAcres,
      'student_intake': studentIntake,
      'average_placement_package_lpa': averagePlacementPackageLpa,
      'affiliatedTo': affiliatedTo,
      'highest_placement_package': highestPlacementPackage,
      'est_year': estYear,
      'description': description,
      'website': website,
      'email': email,
      'phone': phone,
      'logo': logo,
      'category': category,
      'rank': rank,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'rating': rating,
      'fees': fees,
      'user': user,
    }.withoutNulls,
  );

  return firestoreData;
}

class InstitutionsRecordDocumentEquality
    implements Equality<InstitutionsRecord> {
  const InstitutionsRecordDocumentEquality();

  @override
  bool equals(InstitutionsRecord? e1, InstitutionsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.name == e2?.name &&
        e1?.city == e2?.city &&
        e1?.state == e2?.state &&
        e1?.nirf == e2?.nirf &&
        e1?.campusSizeAcres == e2?.campusSizeAcres &&
        e1?.studentIntake == e2?.studentIntake &&
        e1?.averagePlacementPackageLpa == e2?.averagePlacementPackageLpa &&
        listEquality.equals(e1?.instituteImages, e2?.instituteImages) &&
        e1?.affiliatedTo == e2?.affiliatedTo &&
        e1?.highestPlacementPackage == e2?.highestPlacementPackage &&
        e1?.estYear == e2?.estYear &&
        listEquality.equals(e1?.recruiters, e2?.recruiters) &&
        listEquality.equals(e1?.courses, e2?.courses) &&
        e1?.description == e2?.description &&
        e1?.website == e2?.website &&
        e1?.email == e2?.email &&
        e1?.phone == e2?.phone &&
        e1?.logo == e2?.logo &&
        e1?.category == e2?.category &&
        e1?.rank == e2?.rank &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.rating == e2?.rating &&
        e1?.fees == e2?.fees &&
        e1?.user == e2?.user;
  }

  @override
  int hash(InstitutionsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.city,
        e?.state,
        e?.nirf,
        e?.campusSizeAcres,
        e?.studentIntake,
        e?.averagePlacementPackageLpa,
        e?.instituteImages,
        e?.affiliatedTo,
        e?.highestPlacementPackage,
        e?.estYear,
        e?.recruiters,
        e?.courses,
        e?.description,
        e?.website,
        e?.email,
        e?.phone,
        e?.logo,
        e?.category,
        e?.rank,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.rating,
        e?.fees,
        e?.user
      ]);

  @override
  bool isValidKey(Object? o) => o is InstitutionsRecord;
}
