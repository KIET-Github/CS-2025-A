import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CoursesRecord extends FirestoreRecord {
  CoursesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "courseName" field.
  String? _courseName;
  String get courseName => _courseName ?? '';
  bool hasCourseName() => _courseName != null;

  // "stream" field.
  String? _stream;
  String get stream => _stream ?? '';
  bool hasStream() => _stream != null;

  // "degreeType" field.
  String? _degreeType;
  String get degreeType => _degreeType ?? '';
  bool hasDegreeType() => _degreeType != null;

  // "duration" field.
  int? _duration;
  int get duration => _duration ?? 0;
  bool hasDuration() => _duration != null;

  // "mode" field.
  String? _mode;
  String get mode => _mode ?? '';
  bool hasMode() => _mode != null;

  // "intake" field.
  String? _intake;
  String get intake => _intake ?? '';
  bool hasIntake() => _intake != null;

  // "feesPerYear" field.
  double? _feesPerYear;
  double get feesPerYear => _feesPerYear ?? 0.0;
  bool hasFeesPerYear() => _feesPerYear != null;

  // "accreditation" field.
  String? _accreditation;
  String get accreditation => _accreditation ?? '';
  bool hasAccreditation() => _accreditation != null;

  // "courseDescription" field.
  String? _courseDescription;
  String get courseDescription => _courseDescription ?? '';
  bool hasCourseDescription() => _courseDescription != null;

  // "applicationDeadline" field.
  DateTime? _applicationDeadline;
  DateTime? get applicationDeadline => _applicationDeadline;
  bool hasApplicationDeadline() => _applicationDeadline != null;

  // "courseBrochureUrl" field.
  String? _courseBrochureUrl;
  String get courseBrochureUrl => _courseBrochureUrl ?? '';
  bool hasCourseBrochureUrl() => _courseBrochureUrl != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "eligibility10" field.
  double? _eligibility10;
  double get eligibility10 => _eligibility10 ?? 0.0;
  bool hasEligibility10() => _eligibility10 != null;

  // "eligibility12" field.
  double? _eligibility12;
  double get eligibility12 => _eligibility12 ?? 0.0;
  bool hasEligibility12() => _eligibility12 != null;

  // "eligibilityEntrance" field.
  double? _eligibilityEntrance;
  double get eligibilityEntrance => _eligibilityEntrance ?? 0.0;
  bool hasEligibilityEntrance() => _eligibilityEntrance != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _courseName = snapshotData['courseName'] as String?;
    _stream = snapshotData['stream'] as String?;
    _degreeType = snapshotData['degreeType'] as String?;
    _duration = castToType<int>(snapshotData['duration']);
    _mode = snapshotData['mode'] as String?;
    _intake = snapshotData['intake'] as String?;
    _feesPerYear = castToType<double>(snapshotData['feesPerYear']);
    _accreditation = snapshotData['accreditation'] as String?;
    _courseDescription = snapshotData['courseDescription'] as String?;
    _applicationDeadline = snapshotData['applicationDeadline'] as DateTime?;
    _courseBrochureUrl = snapshotData['courseBrochureUrl'] as String?;
    _createdAt = snapshotData['createdAt'] as DateTime?;
    _eligibility10 = castToType<double>(snapshotData['eligibility10']);
    _eligibility12 = castToType<double>(snapshotData['eligibility12']);
    _eligibilityEntrance =
        castToType<double>(snapshotData['eligibilityEntrance']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('courses')
          : FirebaseFirestore.instance.collectionGroup('courses');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('courses').doc(id);

  static Stream<CoursesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CoursesRecord.fromSnapshot(s));

  static Future<CoursesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CoursesRecord.fromSnapshot(s));

  static CoursesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CoursesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CoursesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CoursesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CoursesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CoursesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCoursesRecordData({
  String? courseName,
  String? stream,
  String? degreeType,
  int? duration,
  String? mode,
  String? intake,
  double? feesPerYear,
  String? accreditation,
  String? courseDescription,
  DateTime? applicationDeadline,
  String? courseBrochureUrl,
  DateTime? createdAt,
  double? eligibility10,
  double? eligibility12,
  double? eligibilityEntrance,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'courseName': courseName,
      'stream': stream,
      'degreeType': degreeType,
      'duration': duration,
      'mode': mode,
      'intake': intake,
      'feesPerYear': feesPerYear,
      'accreditation': accreditation,
      'courseDescription': courseDescription,
      'applicationDeadline': applicationDeadline,
      'courseBrochureUrl': courseBrochureUrl,
      'createdAt': createdAt,
      'eligibility10': eligibility10,
      'eligibility12': eligibility12,
      'eligibilityEntrance': eligibilityEntrance,
    }.withoutNulls,
  );

  return firestoreData;
}

class CoursesRecordDocumentEquality implements Equality<CoursesRecord> {
  const CoursesRecordDocumentEquality();

  @override
  bool equals(CoursesRecord? e1, CoursesRecord? e2) {
    return e1?.courseName == e2?.courseName &&
        e1?.stream == e2?.stream &&
        e1?.degreeType == e2?.degreeType &&
        e1?.duration == e2?.duration &&
        e1?.mode == e2?.mode &&
        e1?.intake == e2?.intake &&
        e1?.feesPerYear == e2?.feesPerYear &&
        e1?.accreditation == e2?.accreditation &&
        e1?.courseDescription == e2?.courseDescription &&
        e1?.applicationDeadline == e2?.applicationDeadline &&
        e1?.courseBrochureUrl == e2?.courseBrochureUrl &&
        e1?.createdAt == e2?.createdAt &&
        e1?.eligibility10 == e2?.eligibility10 &&
        e1?.eligibility12 == e2?.eligibility12 &&
        e1?.eligibilityEntrance == e2?.eligibilityEntrance;
  }

  @override
  int hash(CoursesRecord? e) => const ListEquality().hash([
        e?.courseName,
        e?.stream,
        e?.degreeType,
        e?.duration,
        e?.mode,
        e?.intake,
        e?.feesPerYear,
        e?.accreditation,
        e?.courseDescription,
        e?.applicationDeadline,
        e?.courseBrochureUrl,
        e?.createdAt,
        e?.eligibility10,
        e?.eligibility12,
        e?.eligibilityEntrance
      ]);

  @override
  bool isValidKey(Object? o) => o is CoursesRecord;
}
