import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CollegeApplicationRecord extends FirestoreRecord {
  CollegeApplicationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "college" field.
  DocumentReference? _college;
  DocumentReference? get college => _college;
  bool hasCollege() => _college != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "accepted" field.
  bool? _accepted;
  bool get accepted => _accepted ?? false;
  bool hasAccepted() => _accepted != null;

  void _initializeFields() {
    _user = snapshotData['user'] as DocumentReference?;
    _college = snapshotData['college'] as DocumentReference?;
    _createdTime = snapshotData['createdTime'] as DateTime?;
    _accepted = snapshotData['accepted'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('CollegeApplication');

  static Stream<CollegeApplicationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CollegeApplicationRecord.fromSnapshot(s));

  static Future<CollegeApplicationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => CollegeApplicationRecord.fromSnapshot(s));

  static CollegeApplicationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CollegeApplicationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CollegeApplicationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CollegeApplicationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CollegeApplicationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CollegeApplicationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCollegeApplicationRecordData({
  DocumentReference? user,
  DocumentReference? college,
  DateTime? createdTime,
  bool? accepted,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user': user,
      'college': college,
      'createdTime': createdTime,
      'accepted': accepted,
    }.withoutNulls,
  );

  return firestoreData;
}

class CollegeApplicationRecordDocumentEquality
    implements Equality<CollegeApplicationRecord> {
  const CollegeApplicationRecordDocumentEquality();

  @override
  bool equals(CollegeApplicationRecord? e1, CollegeApplicationRecord? e2) {
    return e1?.user == e2?.user &&
        e1?.college == e2?.college &&
        e1?.createdTime == e2?.createdTime &&
        e1?.accepted == e2?.accepted;
  }

  @override
  int hash(CollegeApplicationRecord? e) => const ListEquality()
      .hash([e?.user, e?.college, e?.createdTime, e?.accepted]);

  @override
  bool isValidKey(Object? o) => o is CollegeApplicationRecord;
}
