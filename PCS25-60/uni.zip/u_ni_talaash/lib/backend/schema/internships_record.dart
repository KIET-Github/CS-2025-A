import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class InternshipsRecord extends FirestoreRecord {
  InternshipsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "industry" field.
  String? _industry;
  String get industry => _industry ?? '';
  bool hasIndustry() => _industry != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "logoUrl" field.
  String? _logoUrl;
  String get logoUrl => _logoUrl ?? '';
  bool hasLogoUrl() => _logoUrl != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "verified" field.
  bool? _verified;
  bool get verified => _verified ?? false;
  bool hasVerified() => _verified != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _email = snapshotData['email'] as String?;
    _industry = snapshotData['industry'] as String?;
    _website = snapshotData['website'] as String?;
    _logoUrl = snapshotData['logoUrl'] as String?;
    _createdAt = snapshotData['createdAt'] as DateTime?;
    _verified = snapshotData['verified'] as bool?;
    _user = snapshotData['user'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Internships');

  static Stream<InternshipsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => InternshipsRecord.fromSnapshot(s));

  static Future<InternshipsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => InternshipsRecord.fromSnapshot(s));

  static InternshipsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      InternshipsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static InternshipsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      InternshipsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'InternshipsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is InternshipsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createInternshipsRecordData({
  String? name,
  String? email,
  String? industry,
  String? website,
  String? logoUrl,
  DateTime? createdAt,
  bool? verified,
  DocumentReference? user,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'email': email,
      'industry': industry,
      'website': website,
      'logoUrl': logoUrl,
      'createdAt': createdAt,
      'verified': verified,
      'user': user,
    }.withoutNulls,
  );

  return firestoreData;
}

class InternshipsRecordDocumentEquality implements Equality<InternshipsRecord> {
  const InternshipsRecordDocumentEquality();

  @override
  bool equals(InternshipsRecord? e1, InternshipsRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.email == e2?.email &&
        e1?.industry == e2?.industry &&
        e1?.website == e2?.website &&
        e1?.logoUrl == e2?.logoUrl &&
        e1?.createdAt == e2?.createdAt &&
        e1?.verified == e2?.verified &&
        e1?.user == e2?.user;
  }

  @override
  int hash(InternshipsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.email,
        e?.industry,
        e?.website,
        e?.logoUrl,
        e?.createdAt,
        e?.verified,
        e?.user
      ]);

  @override
  bool isValidKey(Object? o) => o is InternshipsRecord;
}
