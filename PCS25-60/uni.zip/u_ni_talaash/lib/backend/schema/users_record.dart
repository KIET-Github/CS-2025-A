import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "education_level" field.
  String? _educationLevel;
  String get educationLevel => _educationLevel ?? '';
  bool hasEducationLevel() => _educationLevel != null;

  // "institute_name" field.
  String? _instituteName;
  String get instituteName => _instituteName ?? '';
  bool hasInstituteName() => _instituteName != null;

  // "board_name" field.
  String? _boardName;
  String get boardName => _boardName ?? '';
  bool hasBoardName() => _boardName != null;

  // "stream_spcl" field.
  String? _streamSpcl;
  String get streamSpcl => _streamSpcl ?? '';
  bool hasStreamSpcl() => _streamSpcl != null;

  // "year_of_passing" field.
  int? _yearOfPassing;
  int get yearOfPassing => _yearOfPassing ?? 0;
  bool hasYearOfPassing() => _yearOfPassing != null;

  // "class10" field.
  double? _class10;
  double get class10 => _class10 ?? 0.0;
  bool hasClass10() => _class10 != null;

  // "class12" field.
  double? _class12;
  double get class12 => _class12 ?? 0.0;
  bool hasClass12() => _class12 != null;

  // "graduation_no" field.
  String? _graduationNo;
  String get graduationNo => _graduationNo ?? '';
  bool hasGraduationNo() => _graduationNo != null;

  // "entrance" field.
  String? _entrance;
  String get entrance => _entrance ?? '';
  bool hasEntrance() => _entrance != null;

  // "class10_file" field.
  String? _class10File;
  String get class10File => _class10File ?? '';
  bool hasClass10File() => _class10File != null;

  // "class12_file" field.
  String? _class12File;
  String get class12File => _class12File ?? '';
  bool hasClass12File() => _class12File != null;

  // "graduation_file" field.
  String? _graduationFile;
  String get graduationFile => _graduationFile ?? '';
  bool hasGraduationFile() => _graduationFile != null;

  // "entrance_file" field.
  String? _entranceFile;
  String get entranceFile => _entranceFile ?? '';
  bool hasEntranceFile() => _entranceFile != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "friends" field.
  List<DocumentReference>? _friends;
  List<DocumentReference> get friends => _friends ?? const [];
  bool hasFriends() => _friends != null;

  // "skills" field.
  List<String>? _skills;
  List<String> get skills => _skills ?? const [];
  bool hasSkills() => _skills != null;

  // "savedPosts" field.
  List<DocumentReference>? _savedPosts;
  List<DocumentReference> get savedPosts => _savedPosts ?? const [];
  bool hasSavedPosts() => _savedPosts != null;

  // "savedColleges" field.
  List<DocumentReference>? _savedColleges;
  List<DocumentReference> get savedColleges => _savedColleges ?? const [];
  bool hasSavedColleges() => _savedColleges != null;

  // "collegesApplied" field.
  List<DocumentReference>? _collegesApplied;
  List<DocumentReference> get collegesApplied => _collegesApplied ?? const [];
  bool hasCollegesApplied() => _collegesApplied != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _educationLevel = snapshotData['education_level'] as String?;
    _instituteName = snapshotData['institute_name'] as String?;
    _boardName = snapshotData['board_name'] as String?;
    _streamSpcl = snapshotData['stream_spcl'] as String?;
    _yearOfPassing = castToType<int>(snapshotData['year_of_passing']);
    _class10 = castToType<double>(snapshotData['class10']);
    _class12 = castToType<double>(snapshotData['class12']);
    _graduationNo = snapshotData['graduation_no'] as String?;
    _entrance = snapshotData['entrance'] as String?;
    _class10File = snapshotData['class10_file'] as String?;
    _class12File = snapshotData['class12_file'] as String?;
    _graduationFile = snapshotData['graduation_file'] as String?;
    _entranceFile = snapshotData['entrance_file'] as String?;
    _bio = snapshotData['bio'] as String?;
    _username = snapshotData['username'] as String?;
    _friends = getDataList(snapshotData['friends']);
    _skills = getDataList(snapshotData['skills']);
    _savedPosts = getDataList(snapshotData['savedPosts']);
    _savedColleges = getDataList(snapshotData['savedColleges']);
    _collegesApplied = getDataList(snapshotData['collegesApplied']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? educationLevel,
  String? instituteName,
  String? boardName,
  String? streamSpcl,
  int? yearOfPassing,
  double? class10,
  double? class12,
  String? graduationNo,
  String? entrance,
  String? class10File,
  String? class12File,
  String? graduationFile,
  String? entranceFile,
  String? bio,
  String? username,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'education_level': educationLevel,
      'institute_name': instituteName,
      'board_name': boardName,
      'stream_spcl': streamSpcl,
      'year_of_passing': yearOfPassing,
      'class10': class10,
      'class12': class12,
      'graduation_no': graduationNo,
      'entrance': entrance,
      'class10_file': class10File,
      'class12_file': class12File,
      'graduation_file': graduationFile,
      'entrance_file': entranceFile,
      'bio': bio,
      'username': username,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.educationLevel == e2?.educationLevel &&
        e1?.instituteName == e2?.instituteName &&
        e1?.boardName == e2?.boardName &&
        e1?.streamSpcl == e2?.streamSpcl &&
        e1?.yearOfPassing == e2?.yearOfPassing &&
        e1?.class10 == e2?.class10 &&
        e1?.class12 == e2?.class12 &&
        e1?.graduationNo == e2?.graduationNo &&
        e1?.entrance == e2?.entrance &&
        e1?.class10File == e2?.class10File &&
        e1?.class12File == e2?.class12File &&
        e1?.graduationFile == e2?.graduationFile &&
        e1?.entranceFile == e2?.entranceFile &&
        e1?.bio == e2?.bio &&
        e1?.username == e2?.username &&
        listEquality.equals(e1?.friends, e2?.friends) &&
        listEquality.equals(e1?.skills, e2?.skills) &&
        listEquality.equals(e1?.savedPosts, e2?.savedPosts) &&
        listEquality.equals(e1?.savedColleges, e2?.savedColleges) &&
        listEquality.equals(e1?.collegesApplied, e2?.collegesApplied);
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.educationLevel,
        e?.instituteName,
        e?.boardName,
        e?.streamSpcl,
        e?.yearOfPassing,
        e?.class10,
        e?.class12,
        e?.graduationNo,
        e?.entrance,
        e?.class10File,
        e?.class12File,
        e?.graduationFile,
        e?.entranceFile,
        e?.bio,
        e?.username,
        e?.friends,
        e?.skills,
        e?.savedPosts,
        e?.savedColleges,
        e?.collegesApplied
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
