import '/components/side_bar_company_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dashboard_company_widget.dart' show DashboardCompanyWidget;
import 'package:flutter/material.dart';

class DashboardCompanyModel extends FlutterFlowModel<DashboardCompanyWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for sideBarCompany component.
  late SideBarCompanyModel sideBarCompanyModel;

  @override
  void initState(BuildContext context) {
    sideBarCompanyModel = createModel(context, () => SideBarCompanyModel());
  }

  @override
  void dispose() {
    sideBarCompanyModel.dispose();
  }
}
