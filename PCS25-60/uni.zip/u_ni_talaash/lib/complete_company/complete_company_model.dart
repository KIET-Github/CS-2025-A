import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'complete_company_widget.dart' show CompleteCompanyWidget;
import 'package:flutter/material.dart';

class CompleteCompanyModel extends FlutterFlowModel<CompleteCompanyWidget> {
  ///  Local state fields for this page.

  List<String> recruiters = [];
  void addToRecruiters(String item) => recruiters.add(item);
  void removeFromRecruiters(String item) => recruiters.remove(item);
  void removeAtIndexFromRecruiters(int index) => recruiters.removeAt(index);
  void insertAtIndexInRecruiters(int index, String item) =>
      recruiters.insert(index, item);
  void updateRecruitersAtIndex(int index, Function(String) updateFn) =>
      recruiters[index] = updateFn(recruiters[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for PageView widget.
  PageController? pageViewController;

  int get pageViewCurrentIndex => pageViewController != null &&
          pageViewController!.hasClients &&
          pageViewController!.page != null
      ? pageViewController!.page!.round()
      : 0;
  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for companyname widget.
  FocusNode? companynameFocusNode;
  TextEditingController? companynameTextController;
  String? Function(BuildContext, String?)? companynameTextControllerValidator;
  // State field(s) for emailAddress widget.
  FocusNode? emailAddressFocusNode;
  TextEditingController? emailAddressTextController;
  String? Function(BuildContext, String?)? emailAddressTextControllerValidator;
  // State field(s) for website widget.
  FocusNode? websiteFocusNode;
  TextEditingController? websiteTextController;
  String? Function(BuildContext, String?)? websiteTextControllerValidator;
  // State field(s) for industry widget.
  String? industryValue;
  FormFieldController<String>? industryValueController;
  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  InternshipsRecord? update;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    companynameFocusNode?.dispose();
    companynameTextController?.dispose();

    emailAddressFocusNode?.dispose();
    emailAddressTextController?.dispose();

    websiteFocusNode?.dispose();
    websiteTextController?.dispose();
  }
}
