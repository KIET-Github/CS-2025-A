import '/flutter_flow/flutter_flow_util.dart';
import 'profile_setting_items_widget.dart' show ProfileSettingItemsWidget;
import 'package:flutter/material.dart';

class ProfileSettingItemsModel
    extends FlutterFlowModel<ProfileSettingItemsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
