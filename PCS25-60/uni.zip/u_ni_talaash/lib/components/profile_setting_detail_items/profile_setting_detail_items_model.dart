import '/flutter_flow/flutter_flow_util.dart';
import 'profile_setting_detail_items_widget.dart'
    show ProfileSettingDetailItemsWidget;
import 'package:flutter/material.dart';

class ProfileSettingDetailItemsModel
    extends FlutterFlowModel<ProfileSettingDetailItemsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
