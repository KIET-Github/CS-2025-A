import '/flutter_flow/flutter_flow_util.dart';
import 'apply_widget.dart' show ApplyWidget;
import 'package:flutter/material.dart';

class ApplyModel extends FlutterFlowModel<ApplyWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for cb_terms widget.
  bool? cbTermsValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
