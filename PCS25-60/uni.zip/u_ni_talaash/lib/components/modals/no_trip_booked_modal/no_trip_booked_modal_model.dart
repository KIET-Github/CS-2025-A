import '/flutter_flow/flutter_flow_util.dart';
import 'no_trip_booked_modal_widget.dart' show NoTripBookedModalWidget;
import 'package:flutter/material.dart';

class NoTripBookedModalModel extends FlutterFlowModel<NoTripBookedModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
