import '/flutter_flow/flutter_flow_util.dart';
import 'side_bar_company_widget.dart' show SideBarCompanyWidget;
import 'package:flutter/material.dart';

class SideBarCompanyModel extends FlutterFlowModel<SideBarCompanyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
