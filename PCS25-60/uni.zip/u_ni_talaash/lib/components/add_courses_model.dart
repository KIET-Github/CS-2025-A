import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'add_courses_widget.dart' show AddCoursesWidget;
import 'package:flutter/material.dart';

class AddCoursesModel extends FlutterFlowModel<AddCoursesWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for coursename widget.
  FocusNode? coursenameFocusNode;
  TextEditingController? coursenameTextController;
  String? Function(BuildContext, String?)? coursenameTextControllerValidator;
  // State field(s) for stream widget.
  String? streamValue;
  FormFieldController<String>? streamValueController;
  // State field(s) for degreetype widget.
  String? degreetypeValue;
  FormFieldController<String>? degreetypeValueController;
  // State field(s) for duration widget.
  FocusNode? durationFocusNode;
  TextEditingController? durationTextController;
  String? Function(BuildContext, String?)? durationTextControllerValidator;
  // State field(s) for mode widget.
  String? modeValue;
  FormFieldController<String>? modeValueController;
  // State field(s) for marks10 widget.
  FocusNode? marks10FocusNode;
  TextEditingController? marks10TextController;
  String? Function(BuildContext, String?)? marks10TextControllerValidator;
  // State field(s) for marks12 widget.
  FocusNode? marks12FocusNode;
  TextEditingController? marks12TextController;
  String? Function(BuildContext, String?)? marks12TextControllerValidator;
  // State field(s) for entrancescore widget.
  FocusNode? entrancescoreFocusNode;
  TextEditingController? entrancescoreTextController;
  String? Function(BuildContext, String?)? entrancescoreTextControllerValidator;
  // State field(s) for StudentsINtake widget.
  FocusNode? studentsINtakeFocusNode;
  TextEditingController? studentsINtakeTextController;
  String? Function(BuildContext, String?)?
      studentsINtakeTextControllerValidator;
  // State field(s) for Fees widget.
  FocusNode? feesFocusNode;
  TextEditingController? feesTextController;
  String? Function(BuildContext, String?)? feesTextControllerValidator;
  // State field(s) for Accredtaion widget.
  FormFieldController<String>? accredtaionValueController;
  // State field(s) for Description widget.
  FocusNode? descriptionFocusNode;
  TextEditingController? descriptionTextController;
  String? Function(BuildContext, String?)? descriptionTextControllerValidator;
  // State field(s) for Calendar widget.
  DateTimeRange? calendarSelectedDay;
  // State field(s) for cb_terms widget.
  bool? cbTermsValue;

  @override
  void initState(BuildContext context) {
    calendarSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  @override
  void dispose() {
    coursenameFocusNode?.dispose();
    coursenameTextController?.dispose();

    durationFocusNode?.dispose();
    durationTextController?.dispose();

    marks10FocusNode?.dispose();
    marks10TextController?.dispose();

    marks12FocusNode?.dispose();
    marks12TextController?.dispose();

    entrancescoreFocusNode?.dispose();
    entrancescoreTextController?.dispose();

    studentsINtakeFocusNode?.dispose();
    studentsINtakeTextController?.dispose();

    feesFocusNode?.dispose();
    feesTextController?.dispose();

    descriptionFocusNode?.dispose();
    descriptionTextController?.dispose();
  }

  /// Additional helper methods.
  String? get accredtaionValue => accredtaionValueController?.value;
}
