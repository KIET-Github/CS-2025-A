import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'create_profile2_widget.dart' show CreateProfile2Widget;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class CreateProfile2Model extends FlutterFlowModel<CreateProfile2Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for educationLevel widget.
  String? educationLevelValue;
  FormFieldController<String>? educationLevelValueController;
  // State field(s) for schoolCollegename widget.
  FocusNode? schoolCollegenameFocusNode;
  TextEditingController? schoolCollegenameTextController;
  String? Function(BuildContext, String?)?
      schoolCollegenameTextControllerValidator;
  // State field(s) for boardUniv widget.
  FocusNode? boardUnivFocusNode;
  TextEditingController? boardUnivTextController;
  String? Function(BuildContext, String?)? boardUnivTextControllerValidator;
  // State field(s) for stream widget.
  FocusNode? streamFocusNode;
  TextEditingController? streamTextController;
  String? Function(BuildContext, String?)? streamTextControllerValidator;
  // State field(s) for yop widget.
  FocusNode? yopFocusNode;
  TextEditingController? yopTextController;
  final yopMask = MaskTextInputFormatter(mask: '####');
  String? Function(BuildContext, String?)? yopTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    schoolCollegenameFocusNode?.dispose();
    schoolCollegenameTextController?.dispose();

    boardUnivFocusNode?.dispose();
    boardUnivTextController?.dispose();

    streamFocusNode?.dispose();
    streamTextController?.dispose();

    yopFocusNode?.dispose();
    yopTextController?.dispose();
  }
}
