import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'create_profile3_widget.dart' show CreateProfile3Widget;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class CreateProfile3Model extends FlutterFlowModel<CreateProfile3Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Class10 widget.
  FocusNode? class10FocusNode;
  TextEditingController? class10TextController;
  String? Function(BuildContext, String?)? class10TextControllerValidator;
  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl1 = '';

  // State field(s) for class12 widget.
  FocusNode? class12FocusNode;
  TextEditingController? class12TextController;
  String? Function(BuildContext, String?)? class12TextControllerValidator;
  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // State field(s) for Graduation widget.
  FocusNode? graduationFocusNode;
  TextEditingController? graduationTextController;
  String? Function(BuildContext, String?)? graduationTextControllerValidator;
  bool isDataUploading3 = false;
  FFUploadedFile uploadedLocalFile3 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl3 = '';

  // State field(s) for entrance widget.
  FocusNode? entranceFocusNode;
  TextEditingController? entranceTextController;
  final entranceMask = MaskTextInputFormatter(mask: '####');
  String? Function(BuildContext, String?)? entranceTextControllerValidator;
  bool isDataUploading4 = false;
  FFUploadedFile uploadedLocalFile4 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl4 = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    class10FocusNode?.dispose();
    class10TextController?.dispose();

    class12FocusNode?.dispose();
    class12TextController?.dispose();

    graduationFocusNode?.dispose();
    graduationTextController?.dispose();

    entranceFocusNode?.dispose();
    entranceTextController?.dispose();
  }
}
