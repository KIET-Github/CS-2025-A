import '/backend/backend.dart';
import '/components/side_bar_nav_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'dashboard_profile_widget.dart' show DashboardProfileWidget;
import 'package:flutter/material.dart';

class DashboardProfileModel extends FlutterFlowModel<DashboardProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for sideBarNav component.
  late SideBarNavModel sideBarNavModel;
  bool isDataUploading1 = false;
  List<FFUploadedFile> uploadedLocalFiles1 = [];
  List<String> uploadedFileUrls1 = [];

  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // State field(s) for name widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameTextController;
  String? Function(BuildContext, String?)? nameTextControllerValidator;
  // State field(s) for city widget.
  FocusNode? cityFocusNode;
  TextEditingController? cityTextController;
  String? Function(BuildContext, String?)? cityTextControllerValidator;
  // State field(s) for state widget.
  FocusNode? stateFocusNode;
  TextEditingController? stateTextController;
  String? Function(BuildContext, String?)? stateTextControllerValidator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode;
  TextEditingController? emailAddressCreateTextController;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextControllerValidator;
  // State field(s) for established_year widget.
  FocusNode? establishedYearFocusNode;
  TextEditingController? establishedYearTextController;
  String? Function(BuildContext, String?)?
      establishedYearTextControllerValidator;
  // State field(s) for campus_size_acres widget.
  FocusNode? campusSizeAcresFocusNode;
  TextEditingController? campusSizeAcresTextController;
  String? Function(BuildContext, String?)?
      campusSizeAcresTextControllerValidator;
  // State field(s) for student_intake widget.
  FocusNode? studentIntakeFocusNode;
  TextEditingController? studentIntakeTextController;
  String? Function(BuildContext, String?)? studentIntakeTextControllerValidator;
  // State field(s) for RankingSource widget.
  String? rankingSourceValue;
  FormFieldController<String>? rankingSourceValueController;
  bool isDataUploading3 = false;
  FFUploadedFile uploadedLocalFile3 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl3 = '';

  // State field(s) for year widget.
  FocusNode? yearFocusNode;
  TextEditingController? yearTextController;
  String? Function(BuildContext, String?)? yearTextControllerValidator;
  // State field(s) for national_rank widget.
  FocusNode? nationalRankFocusNode;
  TextEditingController? nationalRankTextController;
  String? Function(BuildContext, String?)? nationalRankTextControllerValidator;
  // State field(s) for average_placement_package_lpa widget.
  FocusNode? averagePlacementPackageLpaFocusNode;
  TextEditingController? averagePlacementPackageLpaTextController;
  String? Function(BuildContext, String?)?
      averagePlacementPackageLpaTextControllerValidator;
  // State field(s) for highest_package_lpa widget.
  FocusNode? highestPackageLpaFocusNode;
  TextEditingController? highestPackageLpaTextController;
  String? Function(BuildContext, String?)?
      highestPackageLpaTextControllerValidator;
  // State field(s) for placement_rate_percent widget.
  FocusNode? placementRatePercentFocusNode;
  TextEditingController? placementRatePercentTextController;
  String? Function(BuildContext, String?)?
      placementRatePercentTextControllerValidator;
  bool isDataUploading4 = false;
  FFUploadedFile uploadedLocalFile4 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl4 = '';

  // State field(s) for recruiters widget.
  FocusNode? recruitersFocusNode;
  TextEditingController? recruitersTextController;
  String? Function(BuildContext, String?)? recruitersTextControllerValidator;
  // State field(s) for description widget.
  FocusNode? descriptionFocusNode;
  TextEditingController? descriptionTextController;
  String? Function(BuildContext, String?)? descriptionTextControllerValidator;
  // State field(s) for website widget.
  FocusNode? websiteFocusNode;
  TextEditingController? websiteTextController;
  String? Function(BuildContext, String?)? websiteTextControllerValidator;
  // State field(s) for contactemail widget.
  FocusNode? contactemailFocusNode;
  TextEditingController? contactemailTextController;
  String? Function(BuildContext, String?)? contactemailTextControllerValidator;
  // State field(s) for contact_phone widget.
  FocusNode? contactPhoneFocusNode;
  TextEditingController? contactPhoneTextController;
  String? Function(BuildContext, String?)? contactPhoneTextControllerValidator;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  InstitutionsRecord? update;

  @override
  void initState(BuildContext context) {
    sideBarNavModel = createModel(context, () => SideBarNavModel());
  }

  @override
  void dispose() {
    sideBarNavModel.dispose();
    nameFocusNode?.dispose();
    nameTextController?.dispose();

    cityFocusNode?.dispose();
    cityTextController?.dispose();

    stateFocusNode?.dispose();
    stateTextController?.dispose();

    emailAddressCreateFocusNode?.dispose();
    emailAddressCreateTextController?.dispose();

    establishedYearFocusNode?.dispose();
    establishedYearTextController?.dispose();

    campusSizeAcresFocusNode?.dispose();
    campusSizeAcresTextController?.dispose();

    studentIntakeFocusNode?.dispose();
    studentIntakeTextController?.dispose();

    yearFocusNode?.dispose();
    yearTextController?.dispose();

    nationalRankFocusNode?.dispose();
    nationalRankTextController?.dispose();

    averagePlacementPackageLpaFocusNode?.dispose();
    averagePlacementPackageLpaTextController?.dispose();

    highestPackageLpaFocusNode?.dispose();
    highestPackageLpaTextController?.dispose();

    placementRatePercentFocusNode?.dispose();
    placementRatePercentTextController?.dispose();

    recruitersFocusNode?.dispose();
    recruitersTextController?.dispose();

    descriptionFocusNode?.dispose();
    descriptionTextController?.dispose();

    websiteFocusNode?.dispose();
    websiteTextController?.dispose();

    contactemailFocusNode?.dispose();
    contactemailTextController?.dispose();

    contactPhoneFocusNode?.dispose();
    contactPhoneTextController?.dispose();
  }
}
